//
//  AppId.swift
//  CallFriendProject
//
//  Created by оля on 06.04.2022.
//

import Foundation

class AppID { 
    static var id = "a1702646e9c7486f8b696261e3a4280b"
    static var token: String? = nil
}
