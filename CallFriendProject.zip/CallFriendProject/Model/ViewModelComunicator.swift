//
//  ViewModelComunicator.swift
//  CallFriendProject
//
//  Created by оля on 12.04.2022.
//

import Foundation
import AgoraRtmKit


class DataCollector {
    var userName: String? = nil
    var calleeName: String? = nil
    var agoraCallKit: AgoraRtmCallKit? = nil
    var isLoggedIn: Bool = false
    
}
