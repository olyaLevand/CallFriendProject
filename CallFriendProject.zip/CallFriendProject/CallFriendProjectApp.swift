//
//  CallFriendProjectApp.swift
//  CallFriendProject
//
//  Created by оля on 06.04.2022.
//

import SwiftUI

@main
struct CallFriendProjectApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
